-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2019 at 07:54 PM
-- Server version: 5.7.17
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `naeldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `car_ID` int(20) NOT NULL,
  `model` varchar(60) NOT NULL,
  `manufacturer` varchar(60) NOT NULL,
  `year_of_production` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_ID`, `model`, `manufacturer`, `year_of_production`) VALUES
(1, 'civic', 'honda', '2008'),
(2, 'avantador', 'lamburgini', '2009'),
(3, 'squdoria', 'ferrari', '2018'),
(4, 'clk', 'mercedes', '2019'),
(5, 'yaris', 'toyota', '2020');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_ID` int(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hashed_password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_ID`, `first_name`, `last_name`, `email`, `hashed_password`) VALUES
(6, 'joanna', 'rahal', 'joana@mubs.edu.lb', '$2y$10$z26SRIQ5wTTda2MK57Ktee7wO9lq9D6qYQgRe6bkOCnt5iG2W/Nte'),
(5, 'Nael', 'Yehya', 'nael.yehya@hotmail.com', '$2y$10$LQMHO.zv2bd4W.YRX8JUUez13NjS.UQRbpTV.lYGi46bPEuKxFEEG'),
(7, 'Haitham', 'Maarouf', 'hmaarouf@mubsedulb', '$2y$10$PbEBJjswDBzl6lyt5C/J9.iv2YD1VCzJ8ehkrI6LXdVQFt0m8jn6G'),
(8, 'Haitham', 'Maarouf', 'hmaarouf@mubs.edu.lb', '$2y$10$n0Ziw4.VHDYYGGkSWONabeng.AY3C298z9GD7xI.2N2cLiN42iZnW'),
(9, 'yehya', 'akar', 'yehyaakar@hotmail.com', '$2y$10$UFKm4AJWcR3643eaPydlJO3L18Ej61Vf.4fiJfpsxoNdXPx0RoNzm');

-- --------------------------------------------------------

--
-- Table structure for table `testdrives`
--

CREATE TABLE `testdrives` (
  `customer_ID` int(20) NOT NULL,
  `car_ID` int(20) NOT NULL,
  `date_of_testdrive` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testdrives`
--

INSERT INTO `testdrives` (`customer_ID`, `car_ID`, `date_of_testdrive`) VALUES
(5, 1, '2019-08-13'),
(5, 1, '2019-08-13'),
(5, 1, '2019-08-13'),
(5, 1, '2019-08-13'),
(5, 1, '2019-08-13'),
(5, 1, '2019-08-13'),
(5, 1, '2019-08-13'),
(5, 1, '2019-08-13'),
(5, 3, '2019-08-07'),
(5, 1, '2019-08-14'),
(5, 3, '2019-08-13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_ID`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `car_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
