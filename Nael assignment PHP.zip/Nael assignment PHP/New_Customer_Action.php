<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "naeldb";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try  {
	
	$connect = mysqli_connect($host, $user,$password,$database);
	 
}

catch (Exception $ex)
{
	echo 'Check the connection';
	
}
 
if(isset($_POST['submit'])) 
{
		$First_name = $_POST['first_name'];
	    $last_name = $_POST['last_name'];	
		$Email = $_POST['Eml'];	
   		
		$password = $_POST['Pwd'];
		$uppercase = preg_match('@[A-Z]@',$password);
		$lowercase = preg_match('@[a-z]@',$password);
		$number = preg_match ('@[0-9]@', $password);
		$specialchars = preg_match ('@[^\w]@',$password);
		$hashed_password =password_hash($password, PASSWORD_DEFAULT);
		if (!$uppercase)
		{$message = "make sure your password hase at least one upper case";
	echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_customer_Form.html" );
	}
					
			if (!$lowercase)
		{$message = "make sure your password hase at least one lower case";
	echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_customer_Form.html" );
	}
			if (!$number)
		{$message = "make sure your password hase at least one number";
	echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_customer_Form.html" );
	}
		if (!$specialchars)
		{$message = "make sure your password must have at least one special charecter";
	echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_customer_Form.html" );
	}
	
	if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {$message = "make sure your email is in correct format";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header( "refresh:1;url=New_customer_Form.html" );}
	
			if( empty($First_name)|| empty($last_name) || empty($Email) || empty($password))
		{
			$message = "None of them should be empty";
        echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_customer_Form.html" );
		}
    
	  
		else {	
		
	    $insert_Query = "insert into customers(first_name,last_name,email,hashed_password) values ('$First_name','$last_name','$Email','$hashed_password')";
	    mysqli_query($connect, $insert_Query);
		$message = "You have succsfully registered";
        echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_Customer_Form.html" );
		}

	

}



mysqli_close($connect);
?>