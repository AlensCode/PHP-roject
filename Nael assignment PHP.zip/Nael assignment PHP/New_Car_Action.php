<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "naeldb";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try  {
	
	$connect = mysqli_connect($host, $user,$password,$database);
	 
}

catch (Exception $ex)
{
	echo 'Check the connection';
	
}
 
if(isset($_POST['insert'])) 
{
		$model = $_POST['model'];
	    $manufacturer = $_POST['manufacturer'];	
		$year_of_production =  $_POST['year_of_production'];			
		
		if(empty($model) || empty($manufacturer) || empty($year_of_production))
		{
			$message = "None of them should be empty";
        echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_Car_Form.html" );
		}
        
		
		else
		{
	    $insert_Query = "insert into cars(model,manufacturer,year_of_production) values ('$model','$manufacturer','$year_of_production')";
	    mysqli_query($connect, $insert_Query);
		$message = "You have entered a new car";
        echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=New_Car_Form.html" );
		}
}


if(isset($_POST['search'])) // to search values into the database
{
	   
	 $search_Query = "select * from cars";
	 $search_Result =  mysqli_query($connect, $search_Query);
	 if(mysqli_num_rows($search_Result)==0)
	 {
		 
		 $message = "No Car is available";
        echo "<script type='text/javascript'>alert('$message');</script>";
		
	 }
	 else
	 {
	 
     echo "<table border='1' width ='50%'> ";
	 
	  echo "<tr>";
		   
		     echo "<td align='center'> car_id</td>";
			 echo "<td align='center'> model</td>";
			 echo "<td align='center'> manufacturer</td>";
			 echo "<td align='center'> year of production</td>";
		    
		  
		   
	echo "</tr>";

	   while ($row = mysqli_fetch_array( $search_Result))
	   {
		  $car_id = $row['car_ID'];
		  $model = $row['model'];
		   $manufacturer = $row['manufacturer'];
		   $year_of_production = $row['year_of_production'];
		   
		   echo "<tr>";
		   
		     echo "<td>";
		   echo $car_id;
		   echo "</td>";
		   
		   echo "<td>";
		   echo $model;
		   echo "</td>";
		   
		    echo "<td>";
		      echo $manufacturer;
		   echo "</td>";
		   
		   echo "<td>";
		      echo $year_of_production;
		   echo "</td>";
		   
		      echo "</tr>";
		   
		   
		   
	   }
	
	 echo "</table>";
	 
	 }
	
}

mysqli_close($connect);
?>