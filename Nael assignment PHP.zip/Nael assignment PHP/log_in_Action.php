<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "naeldb";
session_start();

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try  {
	
	$connect = mysqli_connect($host, $user,$password,$database);
	 
}

catch (Exception $ex)
{
	echo 'Check the connection';
	
}
 
if(isset($_POST['login'])) 
{$email = $_POST['email'];
$unverpwd =$_POST['password'];
$query = "SELECT hashed_password from customers where email ='$email'";
 $result = mysqli_query($connect, $query);
 $row = mysqli_fetch_array( $result);
 $hash = $row['hashed_password'];
 if (password_verify($unverpwd, $hash))
 {
	 $message = "You are logged in ";
        echo "<script type='text/javascript'>alert('$message');</script>";
		
		header( 'Location: Book_a_testdrive_Form.html' );
		$_SESSION["mail"]= $email;
		
 }
else{
	$message = "please register ";
        echo "<script type='text/javascript'>alert('$message');</script>";
		
	
}

}
mysqli_close($connect);
?>