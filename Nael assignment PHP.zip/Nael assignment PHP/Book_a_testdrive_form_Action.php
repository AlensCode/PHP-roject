<?php

session_start();
$email = $_SESSION["mail"];

$host = "localhost";
$user = "root";
$password = "";
$database = "naeldb";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try  {
	
	$connect = mysqli_connect($host, $user,$password,$database);
	 
}

catch (Exception $ex)
{
	echo 'Check the connection';
	
}
if(isset($_POST['book'])) {
$date = new DateTime($_POST['date']);
$now = new DateTime();
$car = $_POST["carList"];
$verdate = $_POST['date'];
if($date < $now) {
     $message = "select a new date  ";
        echo "<script type='text/javascript'>alert('$message');</script>";
		header( "refresh:1;url=Book_a_testdrive_form.html");
		
}
else {
	
$query = "SELECT customer_ID from customers where email ='$email'";
 $result = mysqli_query($connect, $query);
 $row = mysqli_fetch_array( $result);
 $customerid = $row['customer_ID'];
 $query2 = "SELECT car_ID from cars where manufacturer ='$car'";
 $result2 = mysqli_query($connect, $query2);
 $row2 = mysqli_fetch_array( $result2);
 $carid = $row2['car_ID'];
 $insert_Query = "insert into testdrives(customer_ID,car_ID,date_of_testdrive) values ('$customerid','$carid','$verdate')";
	    mysqli_query($connect, $insert_Query);
		$message = "congragulations You have booked a testdrive";
        echo "<script type='text/javascript'>alert('$message');</script>";
	//displaying 
	$search_Query = "select * from cars where car_ID ='$carid'";
	 $search_Result =  mysqli_query($connect, $search_Query);
	 if(mysqli_num_rows($search_Result)==0)
	 {
		 
		 $message = "No Car is available";
        echo "<script type='text/javascript'>alert('$message');</script>";
		
	 }
	 else
	 {
	 
     echo "</br>.<table border='2' width ='50%'> ";
	 
	  echo "<tr>";
		   
		     echo "<td align='center'> car_id</td>";
			 echo "<td align='center'> model</td>";
			 echo "<td align='center'> manufacturer</td>";
			 echo "<td align='center'> year of production</td>";
		    
		  
		   
	echo "</tr>";

	   while ($row = mysqli_fetch_array( $search_Result))
	   {
		  $car_id = $row['car_ID'];
		  $model = $row['model'];
		   $manufacturer = $row['manufacturer'];
		   $year_of_production = $row['year_of_production'];
		   
		   echo "<tr>";
		   
		     echo "<td>";
		   echo $car_id;
		   echo "</td>";
		   
		   echo "<td>";
		   echo $model;
		   echo "</td>";
		   
		    echo "<td>";
		      echo $manufacturer;
		   echo "</td>";
		   
		   echo "<td>";
		      echo $year_of_production;
		   echo "</td>";
		   
		      echo "</tr>";
		   
		   
		   
	   }
	
	 echo "</table>.</br>";
	 
	 }
	
//display customer details 
$search_Query2 = "select customer_ID, first_name, last_name, email from customers where customer_ID ='$customerid'";
	 $search_Result2 =  mysqli_query($connect, $search_Query2);
	 if(mysqli_num_rows($search_Result2)==0)
	 {
		 
		 $message = "No customers are available";
        echo "<script type='text/javascript'>alert('$message');</script>";
		
	 }
	 else
	 {
	
     echo "</br>.<table border='2' width ='50%'> ";
	 
	  echo "<tr>";
		   
		     echo "<td align='center'> customer_id</td>";
			 echo "<td align='center'> first name</td>";
			 echo "<td align='center'> last name</td>";
			 echo "<td align='center'> email</td>";
		    
		  
		   
	echo "</tr>";

	   while ($row = mysqli_fetch_array( $search_Result2))
	   {
		  $customer_id2 = $row['customer_ID'];
		  $customer_name2 = $row['first_name'];
		   $last_name = $row['last_name'];
		   $customer_email2 = $row['email'];
		   
		   echo "<tr>";
		   
		     echo "<td>";
		   echo $customer_id2;
		   echo "</td>";
		   
		   echo "<td>";
		   echo $customer_name2;
		   echo "</td>";
		   
		    echo "<td>";
		      echo $last_name;
		   echo "</td>";
		   
		   echo "<td>";
		      echo $customer_email2;
		   echo "</td>";
		   
		      echo "</tr>";
		   
		   
		   
	   }
	
	 echo "</table>";
	 
	 }		
		
}
}

?>